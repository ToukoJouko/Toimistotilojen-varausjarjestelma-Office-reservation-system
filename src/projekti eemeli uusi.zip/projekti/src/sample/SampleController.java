package sample;

public class SampleController {
}